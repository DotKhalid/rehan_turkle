.. Turkle documentation master file, created by
   sphinx-quickstart on Mon Nov 25 15:49:59 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Turkle's documentation!
==================================

.. toctree::
   :maxdepth: 3
   :caption: Contents:

   README.rst
   ADMINISTRATION.rst
   DOCKER.rst
   APP.rst
   API.rst
   REQUESTERS.rst
   TEMPLATE-GUIDE.rst


Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
